#!/usr/bin/env bash
# desktop.mod — 桌面集成

install_desktop_entry() {
    local name="$1" display="$2" exec_path="$3" icon="$4"
    local ddir="${HOME}/.local/share/applications"
    local idir="${HOME}/.local/share/icons/hicolor/256x256/apps"
    mkdir -p "$ddir" "$idir"

    local icon_dest=""
    if [[ -n "$icon" && -f "$icon" ]]; then
        icon_dest="${idir}/kurali-${name}.png"
        cp "$icon" "$icon_dest" 2>/dev/null || true
    fi

    local df="${ddir}/kurali-${name}.desktop"
    cat > "$df" << EOF
[Desktop Entry]
Name=${display}
Comment=Installed via KuraliAll: ${name}
Exec=${exec_path}
Terminal=false
Type=Application
Categories=Utility;
StartupNotify=true
EOF
    [[ -n "$icon_dest" ]] && echo "Icon=${icon_dest}" >> "$df"

    ok "桌面条目: ${name}"
}

remove_desktop_entry() {
    local name="$1"
    rm -f "${HOME}/.local/share/applications/kurali-${name}.desktop" 2>/dev/null
    rm -f "${HOME}/.local/share/icons/hicolor/256x256/apps/kurali-${name}.png" 2>/dev/null
    has_cmd update-desktop-database && update-desktop-database "${HOME}/.local/share/applications" 2>/dev/null || true
    debug "桌面条目已移除: $name"
}

refresh_desktop() {
    has_cmd update-desktop-database && update-desktop-database "${HOME}/.local/share/applications" 2>/dev/null || true
    has_cmd gtk-update-icon-cache && gtk-update-icon-cache -f "${HOME}/.local/share/icons/hicolor" 2>/dev/null || true
}
